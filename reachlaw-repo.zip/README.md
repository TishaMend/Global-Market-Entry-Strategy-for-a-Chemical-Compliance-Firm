# Global Market Entry Strategy for a Chemical Compliance Firm

**University consulting project, Bayes Business School (Apex Global Consulting team, 5 members)**

A strategic market review for **ReachLaw**, a Helsinki-based provider of chemical regulatory compliance services (1,000+ clients, 60+ countries). The team assessed seven markets and recommended where the firm should expand and how.

📄 **[Full deck (PDF, 67 slides)](ReachLaw_Strategic_Market_Review.pdf)**

> **My role:** Research Analyst. **[EDIT: add 1–2 lines, e.g. "Researched the Turkey and South Korea markets: regulation, competitor landscape and digital/SaaS adoption, and drafted their recommendations."]**

## The problem
Chemical regulation is spreading worldwide (EU REACH, Turkey's KKDIK, K-REACH, India's CMSR, Brazil's Law 15.022/2024), and compliance is increasingly digital. Which markets should ReachLaw prioritise, who does it compete with, and how should it combine consulting with SaaS and AI?

## Approach
1. **Market overview:** sized the global chemical industry (>$5tn, heading to >$7.5tn by 2030) and the regulatory trend.
2. **Country analysis** of Finland, Belgium, the UK, Ukraine, Turkey, South Korea, India and Brazil. For each market:
   - regulatory regime and industry size
   - digital, AI and SaaS adoption
   - competitor mapping (global firms, local specialists, digital platforms)
   - ReachLaw's existing presence and relationships
3. **Industry attractiveness scoring** to rank the markets.
4. **Recommendations** for entry strategy and positioning.

![Market overview](images/market-overview.png)

## Key findings and recommendations
| Priority | Markets | Rationale and strategy |
|---|---|---|
| **High** | India | Lower competition, new CMSR regulation (10,000+ substances in scope), no dominant EU-specialist advisor. Enter early in two phases: help Indian exporters with EU REACH, then lead CMSR advisory. |
| **Strategic** | Turkey, South Korea, Ukraine | Strong export growth and recurring compliance deadlines. Use local partnerships and a "same expertise, new market" positioning. |
| **Selective** | Brazil | Moderate competition and a new REACH-like law. Target multinationals and exporters through a local partner. |
| **Lower** | UK, Belgium, Finland | Saturated or already well established. Focus on niche, complex advisory (e.g. EU+UK dual compliance) and digitalise. |

![Market prioritisation](images/market-prioritisation.png)

![Recommendations](images/recommendations.png)

**Overall:** combine expert advisory with digital tools (a hybrid model) to compete with platforms like Enhesa, and cross-sell multi-market compliance to global clients.

## Skills demonstrated
Market research · competitor analysis · regulatory analysis · strategic recommendations · structured consulting-style presentation · teamwork

*Student project. Shared with permission.*
